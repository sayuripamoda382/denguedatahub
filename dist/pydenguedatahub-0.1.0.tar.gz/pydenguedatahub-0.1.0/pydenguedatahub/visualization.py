import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

def plot_srilanka_weekly(national_df):
    """
    Plot weekly dengue cases for the whole country.
    """
    plt.figure(figsize=(12,6))
    sns.lineplot(x = "start.date", y = "cases", data = national_df, color = "blue")
    plt.title("Weekly Dengue Cases in Sri Lanka")
    plt.xlabel("Week")
    plt.ylabel("Cases")
    plt.grid(True)
    plt.show()


def plot_srilanka_weekly_facet(district_df, year_gap = 2):
    """
    Facet plot: weekly dengue cases for each district
    """
    g = sns.FacetGrid(district_df, col="district", col_wrap=4, height=3.5, sharey=False)
    g.map_dataframe(sns.lineplot, x="start.date", y="cases")
    
    # Format x-axis for each subplot
    for ax in g.axes.flat:
        # Get current ticks (all weeks)
        xticks = ax.get_xticks()
        xticklabels = ax.get_xticklabels()
        
        # Convert ticks to datetime and get year
        years = pd.to_datetime([label.get_text() for label in xticklabels], errors='coerce')
        # Keep only some years (every `year_gap`)
        for i, label in enumerate(ax.get_xticklabels()):
            try:
                if years[i].year % year_gap != 0:
                    label.set_visible(False)
            except:
                label.set_visible(False)

    g.set_axis_labels("Week", "Cases")
    g.set_titles("{col_name}")
    plt.tight_layout()
    plt.show()
