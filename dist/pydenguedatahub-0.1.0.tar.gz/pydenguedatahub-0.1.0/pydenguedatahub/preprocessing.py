import pandas as pd

def preprocess_srilanka_weekly(df, aggregate_yearly=False):
    """
    Preprocess Sri Lanka weekly dengue data.
    - Convert date columns to datetime
    - Aggregate national yearly cases
    - Aggregate district yearly cases
    

    Returns:
        dict: {
            'national': national_df,
            'district': district_df
        } for yearly aggregates OR
        same structure for weekly data
    """
    df = df.copy()
    
    # Convert date columns
    df["start.date"] = pd.to_datetime(df["start.date"])
    df["end.date"] = pd.to_datetime(df["end.date"])
    
    if aggregate_yearly:
        # National dataset: sum cases per year
        national_df = df.groupby("year", as_index=False)["cases"].sum()
        
        # District dataset: sum cases per year per district
        district_df = df.groupby(["year", "district"], as_index=False)["cases"].sum()
    else:
        # Weekly data
        national_df = df.groupby("start.date", as_index=False)["cases"].sum()
        district_df = df.copy()  # keep district-level weekly data intact
    
    return {"national": national_df, "district": district_df}


 